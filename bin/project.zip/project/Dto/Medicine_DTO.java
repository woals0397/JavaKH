package project.Dto;

public class Medicine_DTO {

	  String med_name;
	  int med_price;
	  String med_info;
	  String med_symptom;
	  
	

	public Medicine_DTO() {
		// TODO Auto-generated constructor stub
	}

	public String getMed_name() {
		return med_name;
	}

	public void setMed_name(String med_name) {
		this.med_name = med_name;
	}

	public int getMed_price() {
		return med_price;
	}

	public void setMed_price(int med_price) {
		this.med_price = med_price;
	}

	public String getMed_info() {
		return med_info;
	}

	public void setMed_info(String med_info) {
		this.med_info = med_info;
	}
	public String getMed_symptom() {
		return med_symptom;
	}

	public void setMed_symptom(String med_symptom) {
		this.med_symptom = med_symptom;
	}
	  
}

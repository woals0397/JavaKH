package project.Dto;



public class Review_DTO {

	String rev_id;
	String rev_deptname;
	String rev_docname;
	String rev_content;
	
	 public Review_DTO() {
		// TODO Auto-generated constructor stub
	}

	public String getRev_id() {
		return rev_id;
	}

	public void setRev_id(String rev_id) {
		this.rev_id = rev_id;
	}

	public String getRev_deptname() {
		return rev_deptname;
	}

	public void setRev_deptname(String rev_deptname) {
		this.rev_deptname = rev_deptname;
	}

	public String getRev_docname() {
		return rev_docname;
	}

	public void setRev_docname(String rev_docname) {
		this.rev_docname = rev_docname;
	}

	public String getRev_content() {
		return rev_content;
	}

	public void setRev_content(String rev_content) {
		this.rev_content = rev_content;
	}
	 
	
}

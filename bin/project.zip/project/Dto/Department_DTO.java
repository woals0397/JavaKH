package project.Dto;

public class Department_DTO {

	String dept_name;
	String dept_info;
	
	public Department_DTO() {
		// TODO Auto-generated constructor stub
	}

	public String getDept_name() {
		return dept_name;
	}

	public void setDept_name(String dept_name) {
		this.dept_name = dept_name;
	}

	public String getDept_info() {
		return dept_info;
	}

	public void setDept_info(String dept_info) {
		this.dept_info = dept_info;
	}
	
	
}

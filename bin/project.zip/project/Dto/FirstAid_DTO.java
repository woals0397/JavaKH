package project.Dto;

public class FirstAid_DTO {

	String aid_name;
	String aid_solution;
	
	public FirstAid_DTO() {
		// TODO Auto-generated constructor stub
	}

	public String getAid_name() {
		return aid_name;
	}

	public void setAid_name(String aid_name) {
		this.aid_name = aid_name;
	}

	public String getAid_solution() {
		return aid_solution;
	}

	public void setAid_solution(String aid_solution) {
		this.aid_solution = aid_solution;
	}
	
}

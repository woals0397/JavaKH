package project.info_gui;

import javax.swing.JFrame;

public class firstAidTest extends JFrame{
	
	
	public firstAidTest() {
		setTitle("응급처치 정보");
		
	}//end firstAidTest()

}//end class
